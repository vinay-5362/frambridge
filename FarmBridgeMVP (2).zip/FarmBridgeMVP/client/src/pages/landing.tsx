import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Sprout, Store } from "lucide-react";
import heroImage from "@assets/generated_images/farmer's_market_hero_image.png";

export default function Landing() {
  return (
    <div className="min-h-screen">
      <div className="relative h-screen flex items-center justify-center">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent" />
        </div>
        
        <div className="relative z-10 w-full max-w-4xl mx-auto px-4">
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg">
              FarmBridge
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-2 drop-shadow-md">
              Connecting Farmers Directly with Retailers
            </p>
            <p className="text-lg text-white/80 drop-shadow-md">
              Fresh produce, fair prices, no middlemen
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 max-w-2xl mx-auto mb-8">
            <Link href="/signup?role=farmer" data-testid="link-farmer">
              <Card className="hover-elevate active-elevate-2 backdrop-blur-md bg-white/95 border-2 h-full cursor-pointer">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Sprout className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-2xl">I'm a Farmer</CardTitle>
                  <CardDescription className="text-base">
                    List your products and connect with retailers
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button variant="default" className="w-full" data-testid="button-farmer-signup">
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            </Link>

            <Link href="/signup?role=retailer" data-testid="link-retailer">
              <Card className="hover-elevate active-elevate-2 backdrop-blur-md bg-white/95 border-2 h-full cursor-pointer">
                <CardHeader className="text-center pb-4">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    <Store className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <CardTitle className="text-2xl">I'm a Retailer</CardTitle>
                  <CardDescription className="text-base">
                    Find fresh produce from local farmers
                  </CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <Button variant="default" className="w-full" data-testid="button-retailer-signup">
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            </Link>
          </div>

          <div className="text-center">
            <p className="text-white/80 text-lg">
              Already have an account?{" "}
              <Link href="/login" data-testid="link-login">
                <button className="text-white font-semibold hover:underline" data-testid="button-login-link">
                  Login here
                </button>
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
