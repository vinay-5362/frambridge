import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Plus, LogOut, Package, CheckCircle2, XCircle } from "lucide-react";
import { type Product, type User } from "@shared/schema";
import AddProductDialog from "@/components/add-product-dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function FarmerDashboard() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [showAddProduct, setShowAddProduct] = useState(false);

  const user: User | null = JSON.parse(localStorage.getItem("user") || "null");

  if (!user || user.role !== "farmer") {
    navigate("/");
    return null;
  }

  const { data: products = [], isLoading, refetch } = useQuery<Product[]>({
    queryKey: ["/api/products"],
  });

  const myProducts = (products || []).filter(p => p.farmerId === user.id);
  const activeProducts = myProducts.filter(p => !p.isSold);
  const soldProducts = myProducts.filter(p => p.isSold);

  const handleLogout = () => {
    localStorage.removeItem("user");
    toast({
      title: "Logged out",
      description: "You have been logged out successfully.",
    });
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div>
            <h1 className="text-2xl font-bold text-primary">FarmBridge</h1>
            <p className="text-sm text-muted-foreground">Farmer Dashboard</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="font-medium">{user.name}</p>
              <p className="text-sm text-muted-foreground">{user.phone}</p>
            </div>
            <Button 
              variant="outline" 
              onClick={handleLogout}
              data-testid="button-logout"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="container py-8 px-4 max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2">My Products</h2>
            <p className="text-muted-foreground">
              Manage your product listings and track sales
            </p>
          </div>
          <Button 
            onClick={() => setShowAddProduct(true)}
            size="lg"
            data-testid="button-add-product"
          >
            <Plus className="mr-2 h-5 w-5" />
            Add Product
          </Button>
        </div>

        <Tabs defaultValue="active" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="active" data-testid="tab-active">
              Active ({activeProducts.length})
            </TabsTrigger>
            <TabsTrigger value="sold" data-testid="tab-sold">
              Sold ({soldProducts.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="mt-6">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(3)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <div className="aspect-square bg-muted" />
                    <CardHeader>
                      <div className="h-6 bg-muted rounded w-3/4 mb-2" />
                      <div className="h-4 bg-muted rounded w-1/2" />
                    </CardHeader>
                  </Card>
                ))}
              </div>
            ) : activeProducts.length === 0 ? (
              <Card className="p-12 text-center">
                <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">No active products</h3>
                <p className="text-muted-foreground mb-6">
                  Add your first product to start selling
                </p>
                <Button onClick={() => setShowAddProduct(true)} data-testid="button-add-first-product">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Product
                </Button>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {activeProducts.map((product) => (
                  <ProductCard key={product.id} product={product} onUpdate={refetch} />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="sold" className="mt-6">
            {soldProducts.length === 0 ? (
              <Card className="p-12 text-center">
                <CheckCircle2 className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-xl font-semibold mb-2">No sold products yet</h3>
                <p className="text-muted-foreground">
                  Products marked as sold will appear here
                </p>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {soldProducts.map((product) => (
                  <ProductCard key={product.id} product={product} onUpdate={refetch} />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <AddProductDialog 
        open={showAddProduct} 
        onOpenChange={setShowAddProduct}
        onSuccess={() => {
          refetch();
          setShowAddProduct(false);
        }}
      />
    </div>
  );
}

function ProductCard({ product, onUpdate }: { product: Product; onUpdate: () => void }) {
  const { toast } = useToast();
  const [marking, setMarking] = useState(false);

  const handleMarkSold = async () => {
    setMarking(true);
    try {
      await apiRequest("POST", `/api/products/${product.id}/mark-sold`, {});
      
      toast({
        title: "Product marked as sold",
        description: `${product.name} has been marked as sold.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/products"] });
      onUpdate();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to mark product as sold",
        variant: "destructive",
      });
    } finally {
      setMarking(false);
    }
  };

  return (
    <Card className="overflow-hidden" data-testid={`card-product-${product.id}`}>
      <div className="aspect-square relative overflow-hidden bg-muted">
        {product.imageBase64 ? (
          <img 
            src={product.imageBase64} 
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="flex items-center justify-center h-full">
            <Package className="w-16 h-16 text-muted-foreground" />
          </div>
        )}
        {product.isSold && (
          <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
            <Badge variant="secondary" className="text-lg px-4 py-2">
              SOLD
            </Badge>
          </div>
        )}
      </div>
      <CardHeader className="space-y-1">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-xl">{product.name}</CardTitle>
          <Badge variant="outline">{product.category}</Badge>
        </div>
        <CardDescription className="text-base font-semibold text-foreground">
          ₹{product.price.toFixed(2)} / {product.unit}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Quantity:</span>
            <span className="font-medium">{product.quantity} {product.unit}</span>
          </div>
          
          {!product.isSold && (
            <Button
              variant="outline"
              className="w-full"
              onClick={handleMarkSold}
              disabled={marking}
              data-testid={`button-mark-sold-${product.id}`}
            >
              {marking ? (
                "Marking as sold..."
              ) : (
                <>
                  <CheckCircle2 className="mr-2 h-4 w-4" />
                  Mark as Sold
                </>
              )}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
