import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

export default function Admin() {
  const [, navigate] = useLocation();

  const { data: listings = [], isLoading } = useQuery({
    queryKey: ["/api/admin/listings"],
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              onClick={() => navigate("/")}
              data-testid="button-back"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-primary">FarmBridge Admin</h1>
              <p className="text-sm text-muted-foreground">System Overview</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container py-8 px-4 max-w-7xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">All Listings Data</CardTitle>
            <CardDescription>
              Complete JSON view of all products, contacts, and views
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading data...</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <p className="text-sm text-muted-foreground">
                    Total Records: {JSON.stringify(listings).length} characters
                  </p>
                  <Button
                    variant="outline"
                    onClick={() => {
                      const blob = new Blob([JSON.stringify(listings, null, 2)], { type: "application/json" });
                      const url = URL.createObjectURL(blob);
                      const a = document.createElement("a");
                      a.href = url;
                      a.download = `farmbridge-data-${new Date().toISOString()}.json`;
                      a.click();
                    }}
                    data-testid="button-download"
                  >
                    Download JSON
                  </Button>
                </div>
                <pre 
                  className="bg-muted p-6 rounded-lg overflow-auto max-h-[600px] text-xs font-mono"
                  data-testid="pre-json-data"
                >
                  {JSON.stringify(listings, null, 2)}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
