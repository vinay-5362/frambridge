import { useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, MapPin, LogOut, Package, Phone, MessageCircle, Loader2 } from "lucide-react";
import { type Product, type User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Slider } from "@/components/ui/slider";

export default function RetailerSearch() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [maxDistance, setMaxDistance] = useState(50);
  const [userLat, setUserLat] = useState<number | null>(null);
  const [userLng, setUserLng] = useState<number | null>(null);
  const [gettingLocation, setGettingLocation] = useState(false);

  const user: User | null = JSON.parse(localStorage.getItem("user") || "null");

  if (!user || user.role !== "retailer") {
    navigate("/");
    return null;
  }

  const buildSearchUrl = () => {
    const params = new URLSearchParams();
    if (searchQuery) params.append("q", searchQuery);
    if (userLat !== null) params.append("lat", userLat.toString());
    if (userLng !== null) params.append("lng", userLng.toString());
    if (userLat !== null && userLng !== null) params.append("radius_km", maxDistance.toString());
    return `/api/products/search?${params.toString()}`;
  };

  const { data: products = [], isLoading } = useQuery<any[]>({
    queryKey: ["/api/products/search", searchQuery, userLat, userLng, maxDistance],
    queryFn: async () => {
      const res = await fetch(buildSearchUrl());
      if (!res.ok) throw new Error("Failed to search products");
      return res.json();
    },
  });

  const getLocation = () => {
    if (!navigator.geolocation) {
      toast({
        title: "Location not supported",
        description: "Your browser doesn't support geolocation.",
        variant: "destructive",
      });
      return;
    }

    setGettingLocation(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setUserLat(position.coords.latitude);
        setUserLng(position.coords.longitude);
        setGettingLocation(false);
        toast({
          title: "Location set",
          description: "Now showing products sorted by distance.",
        });
      },
      (error) => {
        setGettingLocation(false);
        toast({
          title: "Location error",
          description: "Unable to get your location.",
          variant: "destructive",
        });
      }
    );
  };

  const filteredProducts = products;

  const handleLogout = () => {
    localStorage.removeItem("user");
    toast({
      title: "Logged out",
      description: "You have been logged out successfully.",
    });
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div>
            <h1 className="text-2xl font-bold text-primary">FarmBridge</h1>
            <p className="text-sm text-muted-foreground">Retailer Search</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="font-medium">{user.name}</p>
              <p className="text-sm text-muted-foreground">{user.phone}</p>
            </div>
            <Button 
              variant="outline" 
              onClick={handleLogout}
              data-testid="button-logout"
            >
              <LogOut className="mr-2 h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="sticky top-16 z-40 w-full bg-background border-b">
        <div className="container py-4 px-4 space-y-4">
          <div className="flex gap-3 max-w-3xl mx-auto">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>
            <Button
              variant="outline"
              onClick={getLocation}
              disabled={gettingLocation}
              data-testid="button-get-location"
            >
              {gettingLocation ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <MapPin className="mr-2 h-4 w-4" />
                  <span className="hidden sm:inline">
                    {userLat && userLng ? "Update" : "Set"} Location
                  </span>
                </>
              )}
            </Button>
          </div>

          {userLat && userLng && (
            <div className="max-w-3xl mx-auto space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Maximum Distance:</span>
                <span className="font-medium">{maxDistance} km</span>
              </div>
              <Slider
                value={[maxDistance]}
                onValueChange={([value]) => setMaxDistance(value)}
                min={1}
                max={100}
                step={1}
                data-testid="slider-distance"
              />
            </div>
          )}
        </div>
      </div>

      <main className="container py-8 px-4 max-w-7xl mx-auto">
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2">
            Available Products {filteredProducts.length > 0 && `(${filteredProducts.length})`}
          </h2>
          {userLat && userLng ? (
            <p className="text-muted-foreground">
              Showing products within {maxDistance} km of your location
            </p>
          ) : (
            <p className="text-muted-foreground">
              Set your location to filter products by distance
            </p>
          )}
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="animate-pulse">
                <div className="aspect-square bg-muted" />
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-3/4 mb-2" />
                  <div className="h-4 bg-muted rounded w-1/2" />
                </CardHeader>
              </Card>
            ))}
          </div>
        ) : filteredProducts.length === 0 ? (
          <Card className="p-12 text-center">
            <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No products found</h3>
            <p className="text-muted-foreground">
              {searchQuery 
                ? "Try adjusting your search or filters"
                : "No products available at the moment"}
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product: any) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                distance={product.distance}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

function ProductCard({ product, distance }: { product: Product; distance?: number }) {
  const [, navigate] = useLocation();

  return (
    <Card 
      className="overflow-hidden hover-elevate active-elevate-2 cursor-pointer"
      onClick={() => navigate(`/product/${product.id}`)}
      data-testid={`card-product-${product.id}`}
    >
      <div className="aspect-square relative overflow-hidden bg-muted">
        {product.imageBase64 ? (
          <img 
            src={product.imageBase64} 
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="flex items-center justify-center h-full">
            <Package className="w-16 h-16 text-muted-foreground" />
          </div>
        )}
      </div>
      <CardHeader className="space-y-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-xl line-clamp-1">{product.name}</CardTitle>
          <Badge variant="outline">{product.category}</Badge>
        </div>
        <CardDescription className="text-lg font-bold text-foreground">
          ₹{product.price.toFixed(2)} / {product.unit}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-muted-foreground">Available:</span>
          <span className="font-medium">{product.quantity} {product.unit}</span>
        </div>
        {distance !== undefined && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>{distance.toFixed(1)} km away</span>
          </div>
        )}
        <div className="pt-2">
          <p className="text-sm text-muted-foreground">Farmer: {product.farmerName}</p>
        </div>
      </CardContent>
    </Card>
  );
}
