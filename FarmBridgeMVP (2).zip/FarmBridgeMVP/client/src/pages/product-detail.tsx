import { useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Phone, MessageCircle, MapPin, Package, User, Calendar, MapPinIcon } from "lucide-react";
import { type Product, type User as UserType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function ProductDetail() {
  const [, params] = useRoute("/product/:id");
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const user: UserType | null = JSON.parse(localStorage.getItem("user") || "null");
  const productId = params?.id;

  const { data: product, isLoading } = useQuery<Product>({
    queryKey: ["/api/products", productId],
    enabled: !!productId,
    queryFn: async () => {
      const res = await fetch(`/api/products/${productId}`);
      if (!res.ok) throw new Error("Product not found");
      return res.json();
    },
  });

  const viewMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", `/api/products/${productId}/view`, {
        viewerPhone: user?.phone || null,
      });
    },
  });

  const contactMutation = useMutation({
    mutationFn: async (method: "call" | "whatsapp") => {
      return await apiRequest("POST", `/api/products/${productId}/contact`, {
        method,
        viewerPhone: user?.phone || "",
      });
    },
    onSuccess: (_, method) => {
      toast({
        title: "Contact logged",
        description: `Your ${method} contact has been recorded.`,
      });
    },
  });

  useEffect(() => {
    if (product && !viewMutation.isSuccess) {
      viewMutation.mutate();
    }
  }, [product]);

  const handleCall = () => {
    if (!product) return;
    contactMutation.mutate("call");
    window.location.href = `tel:${product.farmerPhone}`;
  };

  const handleWhatsApp = () => {
    if (!product) return;
    contactMutation.mutate("whatsapp");
    window.open(`https://wa.me/91${product.farmerPhone}`, "_blank");
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading product...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-md w-full text-center p-8">
          <Package className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
          <h2 className="text-2xl font-bold mb-2">Product not found</h2>
          <p className="text-muted-foreground mb-6">
            The product you're looking for doesn't exist.
          </p>
          <Button onClick={() => navigate("/")} data-testid="button-back-home">
            Go Home
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center px-4">
          <Button 
            variant="ghost" 
            onClick={() => window.history.back()}
            data-testid="button-back"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <h1 className="ml-4 text-xl font-bold text-primary">FarmBridge</h1>
        </div>
      </header>

      <main className="container py-8 px-4 max-w-4xl mx-auto">
        <div className="grid md:grid-cols-2 gap-8">
          <div>
            <div className="aspect-square rounded-lg overflow-hidden bg-muted mb-4">
              {product.imageBase64 ? (
                <img 
                  src={product.imageBase64} 
                  alt={product.name}
                  className="w-full h-full object-cover"
                  data-testid="img-product"
                />
              ) : (
                <div className="flex items-center justify-center h-full">
                  <Package className="w-24 h-24 text-muted-foreground" />
                </div>
              )}
            </div>

            {product.isSold && (
              <Badge variant="secondary" className="w-full justify-center py-2 text-base">
                This product has been sold
              </Badge>
            )}
          </div>

          <div className="space-y-6">
            <div>
              <div className="flex items-start justify-between gap-4 mb-2">
                <h1 className="text-4xl font-bold" data-testid="text-product-name">
                  {product.name}
                </h1>
                <Badge variant="outline" className="text-base px-3 py-1">
                  {product.category}
                </Badge>
              </div>
              <p className="text-3xl font-bold text-primary mb-4" data-testid="text-price">
                ₹{product.price.toFixed(2)} <span className="text-lg text-muted-foreground">/ {product.unit}</span>
              </p>
            </div>

            <Separator />

            <div className="space-y-3">
              <h3 className="font-semibold text-lg">Product Details</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Available Quantity</p>
                  <p className="font-medium" data-testid="text-quantity">
                    {product.quantity} {product.unit}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Category</p>
                  <p className="font-medium">{product.category}</p>
                </div>
              </div>
            </div>

            <Separator />

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Farmer Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Name</p>
                  <p className="font-medium" data-testid="text-farmer-name">{product.farmerName}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Phone</p>
                  <p className="font-medium" data-testid="text-farmer-phone">{product.farmerPhone}</p>
                </div>
                {(product.farmerState || product.farmerAddress) && (
                  <>
                    <Separator />
                    <div>
                      <div className="flex items-center gap-2 mb-3">
                        <MapPinIcon className="h-5 w-5 text-primary" />
                        <p className="font-semibold">Location</p>
                      </div>
                      <div className="space-y-2 pl-7">
                        {product.farmerState && (
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">State/Region</p>
                            <p className="font-medium" data-testid="text-farmer-state">{product.farmerState}</p>
                          </div>
                        )}
                        {product.farmerAddress && (
                          <div>
                            <p className="text-sm text-muted-foreground mb-1">Address</p>
                            <p className="font-medium" data-testid="text-farmer-address">{product.farmerAddress}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>

            <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg p-4 space-y-2">
              <h3 className="font-semibold text-amber-900 dark:text-amber-100">Safety First</h3>
              <p className="text-sm text-amber-800 dark:text-amber-200">
                Always meet the farmer in person to inspect the product before making payment. This ensures you get the best quality and protects both parties.
              </p>
            </div>

            {!product.isSold && (
              <div className="space-y-3">
                <h3 className="font-semibold text-lg">Contact Farmer</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    onClick={handleCall}
                    variant="default"
                    size="lg"
                    className="w-full"
                    data-testid="button-call"
                  >
                    <Phone className="mr-2 h-5 w-5" />
                    Call
                  </Button>
                  <Button
                    onClick={handleWhatsApp}
                    variant="default"
                    size="lg"
                    className="w-full bg-[#25D366] hover:bg-[#20BA5A] text-white"
                    data-testid="button-whatsapp"
                  >
                    <MessageCircle className="mr-2 h-5 w-5" />
                    WhatsApp
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
