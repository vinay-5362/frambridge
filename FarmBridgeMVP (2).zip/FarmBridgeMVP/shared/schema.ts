import { z } from "zod";

// User schema
export const userSchema = z.object({
  id: z.string(),
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().regex(/^\d{10}$/, "Phone must be 10 digits"),
  role: z.enum(["farmer", "retailer"]),
  state: z.string().optional(),
  address: z.string().optional(),
  lat: z.number().min(-90).max(90).nullable(),
  lng: z.number().min(-180).max(180).nullable(),
  createdAt: z.string(),
});

export const insertUserSchema = userSchema.omit({ id: true, createdAt: true }).extend({
  state: z.string().optional(),
  address: z.string().optional(),
  lat: z.number().min(-90).max(90).nullable().default(null),
  lng: z.number().min(-180).max(180).nullable().default(null),
});

export type User = z.infer<typeof userSchema>;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Product schema
export const productSchema = z.object({
  id: z.string(),
  farmerId: z.string(),
  farmerName: z.string(),
  farmerPhone: z.string(),
  farmerState: z.string().optional(),
  farmerAddress: z.string().optional(),
  name: z.string().min(2, "Product name must be at least 2 characters"),
  category: z.string().min(2, "Category is required"),
  unit: z.string().min(1, "Unit is required"),
  price: z.number().positive("Price must be greater than 0"),
  quantity: z.number().positive("Quantity must be greater than 0"),
  imageBase64: z.string().nullable(),
  lat: z.number().min(-90).max(90).default(0),
  lng: z.number().min(-180).max(180).default(0),
  isSold: z.boolean(),
  createdAt: z.string(),
});

export const insertProductSchema = productSchema.omit({ 
  id: true, 
  createdAt: true,
  isSold: true,
  farmerName: true,
  farmerPhone: true,
  farmerState: true,
  farmerAddress: true,
}).extend({
  lat: z.number().min(-90).max(90).default(0),
  lng: z.number().min(-180).max(180).default(0),
});

export type Product = z.infer<typeof productSchema>;
export type InsertProduct = z.infer<typeof insertProductSchema>;

// Contact schema
export const contactSchema = z.object({
  id: z.string(),
  productId: z.string(),
  viewerPhone: z.string(),
  method: z.enum(["call", "whatsapp"]),
  contactedAt: z.string(),
});

export const insertContactSchema = contactSchema.omit({ id: true, contactedAt: true });

export type Contact = z.infer<typeof contactSchema>;
export type InsertContact = z.infer<typeof insertContactSchema>;

// View schema
export const viewSchema = z.object({
  id: z.string(),
  productId: z.string(),
  viewerPhone: z.string().nullable(),
  viewedAt: z.string(),
});

export const insertViewSchema = viewSchema.omit({ id: true, viewedAt: true });

export type View = z.infer<typeof viewSchema>;
export type InsertView = z.infer<typeof insertViewSchema>;
