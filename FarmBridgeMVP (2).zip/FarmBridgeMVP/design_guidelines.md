# FarmBridge MVP Design Guidelines

## Design Approach: Material Design System
**Rationale**: This is a utility-focused marketplace where efficiency, mobile responsiveness, and clear information hierarchy are paramount. Material Design provides excellent patterns for commerce, search, and mobile-first experiences.

## Typography System

**Primary Font**: Roboto (via Google Fonts CDN)
**Secondary Font**: Inter (for numbers/pricing)

**Hierarchy**:
- Hero/Page Titles: 32px/2rem, font-weight: 700
- Section Headers: 24px/1.5rem, font-weight: 600
- Card Titles: 18px/1.125rem, font-weight: 500
- Body Text: 16px/1rem, font-weight: 400
- Captions/Labels: 14px/0.875rem, font-weight: 400
- Small Text: 12px/0.75rem, font-weight: 400

## Layout & Spacing System

**Tailwind Spacing Units**: Use 2, 4, 6, 8, 12, 16 consistently
- Component padding: p-4 (mobile), p-6 (desktop)
- Section spacing: py-8 (mobile), py-12 (desktop)
- Card gaps: gap-4 (mobile), gap-6 (desktop)
- Element margins: mb-2, mb-4, mb-6 for vertical rhythm

**Container Strategy**:
- Mobile-first: Full width with px-4 padding
- Desktop: max-w-7xl mx-auto
- Forms/Content: max-w-md for focused interactions

## Component Library

### Navigation
- **Header**: Fixed top bar with logo, role indicator, logout
- Height: h-16 with shadow
- Mobile: Hamburger menu, Desktop: Horizontal nav

### Cards (Product Listings)
- Image: aspect-ratio-square or 4:3, object-cover
- Structure: Image top, content below with p-4
- Meta info: Small badges for category, location distance
- Price: Prominent, font-weight: 700, larger size
- Grid: 1 column mobile, 2-3 columns desktop (grid-cols-1 md:grid-cols-2 lg:grid-cols-3)

### Forms (Add Product, Signup)
- Single column layout, max-w-md
- Input fields: h-12, rounded-lg, border with focus states
- Labels: mb-2, font-weight: 500
- File upload: Dashed border area with upload icon, preview thumbnail
- Submit buttons: w-full on mobile, min-w-[200px] on desktop

### Buttons
**Primary CTA**: Rounded-lg, px-6, py-3, font-weight: 600
**Secondary**: Outlined variant with border-2
**Icon Buttons**: Call/WhatsApp - rounded-full, p-4, with icon from Heroicons
- When overlaying images: backdrop-blur-sm with semi-transparent background

### Search & Filters
- Search bar: Sticky below header, h-12, rounded-full with search icon
- Filters: Horizontal scrollable chips on mobile, inline on desktop
- Distance slider: Range input with km indicator

### Product Detail Page
- Hero image: h-64 (mobile), h-96 (desktop), object-cover
- Contact section: Sticky bottom bar on mobile with Call/WhatsApp buttons side-by-side
- Farmer info card: Bordered box with avatar placeholder, name, phone
- Product details: Definition list style (label-value pairs)

### Dashboard (Farmer)
- Tab navigation: Underlined active state
- Quick action FAB: Fixed bottom-right, rounded-full, shadow-lg for "Add Product"
- Product management: List view with edit/mark sold actions

### Admin View
- Simple table or JSON viewer
- Monospace font for data display

## Icons
**Library**: Heroicons (via CDN)
**Usage**: 
- Navigation: w-6 h-6
- Cards: w-5 h-5 for metadata icons
- Buttons: w-5 h-5 inline with text
- FAB: w-6 h-6

## Images

### Hero Section (Landing Page)
**Large Hero Image**: Yes - Full viewport hero (h-screen)
- Image: Vibrant agricultural scene - farmer's market with fresh produce, people interacting
- Overlay: Dark gradient from bottom (from-black/60 to-transparent)
- Content: Centered white text with role selection cards overlaid
- CTA Buttons: Two prominent cards "I'm a Farmer" / "I'm a Retailer" with backdrop-blur-md

### Product Images
- Listings grid: Square thumbnails (aspect-square)
- Detail page: Large hero image with rounded corners
- Fallback: Placeholder with produce icon if no image

### Additional Visual Elements
- Empty states: Simple illustrations (can use placeholder services)
- User avatars: Circular placeholders with initials
- Background patterns: Subtle geometric pattern on signup/login pages

## Animations
**Minimal & Purposeful**:
- Page transitions: None (instant navigation)
- Card hover: Subtle scale (scale-105) and shadow increase
- Button press: Quick scale-95 on active
- Image loading: Skeleton shimmer effect
- Success feedback: Simple checkmark animation after product added/marked sold

## Responsive Breakpoints
- Mobile: < 768px (base Tailwind)
- Tablet: 768px - 1024px (md:)
- Desktop: > 1024px (lg:)

## Accessibility
- Touch targets: Minimum h-12 for all interactive elements
- Focus indicators: Clear ring-2 ring-offset-2 on focus
- Alt text: Required for all product images
- Semantic HTML: Proper heading hierarchy, form labels

## Mobile-First Considerations
- Bottom navigation for primary actions
- Thumb-friendly zones: CTAs in lower third on mobile
- Single column forms and content
- Collapsible filters/advanced search
- Geolocation prompt: Clear, contextual explanation before requesting permission