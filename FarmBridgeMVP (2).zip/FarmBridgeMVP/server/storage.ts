import { 
  type User, 
  type InsertUser,
  type Product,
  type InsertProduct,
  type Contact,
  type InsertContact,
  type View,
  type InsertView
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  createUser(user: InsertUser): Promise<User>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  
  createProduct(product: InsertProduct): Promise<Product>;
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  markProductSold(id: string): Promise<void>;
  
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
  
  createView(view: InsertView): Promise<View>;
  getViews(): Promise<View[]>;
  
  getAllListingsData(): Promise<{
    users: User[];
    products: Product[];
    contacts: Contact[];
    views: View[];
  }>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private products: Map<string, Product>;
  private contacts: Map<string, Contact>;
  private views: Map<string, View>;

  constructor() {
    this.users = new Map();
    this.products = new Map();
    this.contacts = new Map();
    this.views = new Map();
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      createdAt: new Date().toISOString(),
    };
    this.users.set(id, user);
    return user;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.phone === phone,
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    
    const farmer = this.users.get(insertProduct.farmerId);
    if (!farmer) {
      throw new Error("Farmer not found");
    }

    const product: Product = {
      ...insertProduct,
      id,
      farmerName: farmer.name,
      farmerPhone: farmer.phone,
      farmerState: farmer.state,
      farmerAddress: farmer.address,
      isSold: false,
      createdAt: new Date().toISOString(),
    };
    
    this.products.set(id, product);
    return product;
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async markProductSold(id: string): Promise<void> {
    const product = this.products.get(id);
    if (!product) {
      throw new Error("Product not found");
    }
    
    const updatedProduct: Product = {
      ...product,
      isSold: true,
    };
    
    this.products.set(id, updatedProduct);
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = {
      ...insertContact,
      id,
      contactedAt: new Date().toISOString(),
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values());
  }

  async createView(insertView: InsertView): Promise<View> {
    const id = randomUUID();
    const view: View = {
      ...insertView,
      id,
      viewedAt: new Date().toISOString(),
    };
    this.views.set(id, view);
    return view;
  }

  async getViews(): Promise<View[]> {
    return Array.from(this.views.values());
  }

  async getAllListingsData(): Promise<{
    users: User[];
    products: Product[];
    contacts: Contact[];
    views: View[];
  }> {
    return {
      users: Array.from(this.users.values()),
      products: Array.from(this.products.values()),
      contacts: Array.from(this.contacts.values()),
      views: Array.from(this.views.values()),
    };
  }
}

export const storage = new MemStorage();
