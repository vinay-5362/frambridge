import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertProductSchema, insertContactSchema, insertViewSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/signup", async (req, res) => {
    try {
      const data = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByPhone(data.phone);
      if (existingUser) {
        return res.status(400).json({ error: "Phone number already registered" });
      }

      const user = await storage.createUser(data);
      res.json(user);
    } catch (error: any) {
      console.error("Signup error:", error);
      res.status(400).json({ error: error.message || "Invalid request" });
    }
  });

  app.post("/api/login", async (req, res) => {
    try {
      const { phone } = req.body;
      
      if (!phone || typeof phone !== "string" || !/^\d{10}$/.test(phone)) {
        return res.status(400).json({ error: "Invalid phone number" });
      }

      const user = await storage.getUserByPhone(phone);
      if (!user) {
        return res.status(404).json({ error: "User not found. Please sign up first." });
      }

      res.json(user);
    } catch (error: any) {
      console.error("Login error:", error);
      res.status(400).json({ error: error.message || "Invalid request" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const data = insertProductSchema.parse(req.body);
      const product = await storage.createProduct(data);
      res.json(product);
    } catch (error: any) {
      console.error("Create product error:", error);
      res.status(400).json({ error: error.message || "Invalid request" });
    }
  });

  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error: any) {
      console.error("Get products error:", error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.get("/api/products/search", async (req, res) => {
    try {
      const { q, lat, lng, radius_km } = req.query;
      
      let products = await storage.getProducts();
      products = products.filter(p => !p.isSold);

      if (q && typeof q === "string") {
        const query = q.toLowerCase();
        products = products.filter(p =>
          p.name.toLowerCase().includes(query) ||
          p.category.toLowerCase().includes(query)
        );
      }

      if (lat && lng && radius_km) {
        const userLat = parseFloat(lat as string);
        const userLng = parseFloat(lng as string);
        const maxDistance = parseFloat(radius_km as string);

        const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
          const R = 6371;
          const dLat = (lat2 - lat1) * Math.PI / 180;
          const dLon = (lon2 - lon1) * Math.PI / 180;
          const a = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon/2) * Math.sin(dLon/2);
          const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
          return R * c;
        };

        products = products
          .map(p => ({
            ...p,
            distance: calculateDistance(userLat, userLng, p.lat, p.lng)
          }))
          .filter(p => p.distance! <= maxDistance)
          .sort((a, b) => a.distance! - b.distance!);
      }

      res.json(products);
    } catch (error: any) {
      console.error("Search products error:", error);
      res.status(500).json({ error: "Failed to search products" });
    }
  });

  app.get("/api/products/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const product = await storage.getProduct(id);
      
      if (!product) {
        return res.status(404).json({ error: "Product not found" });
      }
      
      res.json(product);
    } catch (error: any) {
      console.error("Get product error:", error);
      res.status(500).json({ error: "Failed to fetch product" });
    }
  });

  app.post("/api/products/:id/mark-sold", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.markProductSold(id);
      res.json({ success: true });
    } catch (error: any) {
      console.error("Mark sold error:", error);
      res.status(400).json({ error: error.message || "Failed to mark as sold" });
    }
  });

  app.post("/api/products/:id/contact", async (req, res) => {
    try {
      const { id } = req.params;
      const contactData = insertContactSchema.parse({
        productId: id,
        viewerPhone: req.body.viewerPhone,
        method: req.body.method,
      });
      
      const contact = await storage.createContact(contactData);
      res.json(contact);
    } catch (error: any) {
      console.error("Contact error:", error);
      res.status(400).json({ error: error.message || "Invalid request" });
    }
  });

  app.post("/api/products/:id/view", async (req, res) => {
    try {
      const { id } = req.params;
      const viewData = insertViewSchema.parse({
        productId: id,
        viewerPhone: req.body.viewerPhone || null,
      });
      
      const view = await storage.createView(viewData);
      res.json(view);
    } catch (error: any) {
      console.error("View error:", error);
      res.status(400).json({ error: error.message || "Invalid request" });
    }
  });

  app.get("/api/admin/listings", async (req, res) => {
    try {
      const data = await storage.getAllListingsData();
      res.json(data);
    } catch (error: any) {
      console.error("Admin listings error:", error);
      res.status(500).json({ error: "Failed to fetch listings" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
