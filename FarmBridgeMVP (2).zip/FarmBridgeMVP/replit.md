# FarmBridge MVP

## Overview

FarmBridge is a direct farmer-to-retailer marketplace platform that eliminates middlemen by connecting farmers selling produce with retailers looking to purchase. The platform enables farmers to list products with photos, pricing, and location data, while retailers can search for products by name and distance. Communication happens directly through call and WhatsApp integrations, with no delivery management or payment processing built into the MVP.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- **React 18** with TypeScript using Vite as the build tool
- **Wouter** for lightweight client-side routing
- **TanStack Query v5** for server state management and API caching
- **React Hook Form** with Zod validation for form handling
- **Shadcn UI** (New York style) built on Radix UI primitives for component library
- **Tailwind CSS** for styling with custom design system

**Design System:**
- Material Design approach optimized for mobile-first marketplace experience
- Custom CSS variables for theming with light mode default
- Typography using Roboto/Inter font families via Google Fonts CDN
- Standardized spacing scale (2, 4, 6, 8, 12, 16) and component patterns
- Responsive grid layouts (1 column mobile → 2-3 columns desktop)

**Route Structure:**
- `/` - Landing page with role selection (Farmer/Retailer)
- `/signup` - User registration with role-based routing
- `/farmer/dashboard` - Farmer product management interface
- `/retailer/search` - Product search with distance filtering
- `/product/:id` - Product detail view with contact actions
- `/admin` - Administrative data viewing endpoint

**State Management:**
- User authentication via localStorage (stores user object with ID, phone, role, coordinates)
- No session management or cookies for MVP
- Query invalidation on mutations for data consistency

### Backend Architecture

**Technology Stack:**
- **Node.js** with Express framework
- **TypeScript** with ES modules
- **Drizzle ORM** configured for PostgreSQL (via Neon serverless)
- **In-memory storage fallback** (MemStorage class) for development/testing

**API Design Pattern:**
- RESTful endpoints with JSON request/response format
- Zod schema validation on all inputs
- Error handling with descriptive HTTP status codes
- CORS enabled for cross-origin requests

**Core API Endpoints:**
- `POST /api/signup` - User registration
- `POST /api/products` - Create product listing (farmers only)
- `GET /api/products` - Fetch all products
- `GET /api/products/search` - Search with query, location, and radius filters
- `GET /api/products/:id` - Get single product details
- `POST /api/products/:id/mark-sold` - Update product availability
- `POST /api/products/:id/contact` - Log contact attempts (call/WhatsApp)
- `POST /api/products/:id/view` - Track product views
- `GET /api/admin/listings` - Aggregate data for admin review

**Data Access Layer:**
- `IStorage` interface defines contract for all data operations
- `MemStorage` implementation provides in-memory Map-based storage
- Ready for Drizzle/Postgres implementation swap without API changes

### Data Schema

**Users Table:**
- `id` (UUID primary key)
- `name` (string, min 2 chars)
- `phone` (string, exactly 10 digits, unique)
- `role` (enum: "farmer" | "retailer")
- `lat`, `lng` (nullable numbers for geolocation)
- `createdAt` (ISO timestamp)

**Products Table:**
- `id` (UUID primary key)
- `farmerId` (references user ID)
- `farmerName`, `farmerPhone` (denormalized for quick access)
- `name`, `category`, `unit` (product details)
- `price`, `quantity` (numeric fields)
- `imageBase64` (nullable string - base64 encoded image for MVP)
- `lat`, `lng` (product location coordinates)
- `isSold` (boolean flag)
- `createdAt` (ISO timestamp)

**Contacts Table:**
- `id` (UUID primary key)
- `productId` (references product)
- `viewerPhone` (retailer contact info)
- `method` (enum: "call" | "whatsapp")
- `createdAt` (timestamp for analytics)

**Views Table:**
- `id` (UUID primary key)
- `productId` (references product)
- `viewerPhone` (nullable - tracks who viewed)
- `createdAt` (timestamp for analytics)

**Distance Calculation:**
- Haversine formula implementation in search endpoint
- Filters products within specified `radius_km` parameter
- Requires both user and product to have valid lat/lng coordinates

### Image Handling Strategy

**MVP Approach:**
- Images stored as base64-encoded strings directly in database
- File input on frontend converts image to base64 via FileReader API
- Served as `data:image/*` URIs in API responses
- Preview functionality in upload dialog
- **Limitation:** Not suitable for production scale, should migrate to object storage (S3, Cloudinary) for real deployment

### Authentication & Authorization

**Simplified OTP-less Approach:**
- No SMS verification or password authentication
- Phone number uniqueness enforced at signup
- User object stored in localStorage after signup
- Role-based UI routing (farmers → dashboard, retailers → search)
- No backend session management or JWT tokens
- **Security Note:** This is intentionally minimal for MVP demonstration and should not be used in production

## External Dependencies

### Third-Party UI Libraries
- **Radix UI** - Headless accessible component primitives for dialogs, dropdowns, forms, etc.
- **Shadcn UI** - Pre-built component templates configured in `components.json`
- **Lucide React** - Icon library for UI elements

### Development Tools
- **Vite** - Frontend build tool and dev server with HMR
- **Replit-specific plugins** - Runtime error modal, cartographer, dev banner for Replit environment
- **Drizzle Kit** - Database migration and schema management tool
- **ESBuild** - Production server bundling

### Database & Storage
- **Neon Serverless** - PostgreSQL database client (@neondatabase/serverless)
- Configured via `DATABASE_URL` environment variable
- Drizzle ORM for type-safe database queries
- Migration files output to `./migrations` directory

### Geolocation
- Browser Geolocation API for capturing user/product coordinates
- No external geocoding service integration
- Distance calculations performed server-side using Haversine formula

### Communication Integrations
- **Phone calls** - `tel:` URI scheme for native dialer
- **WhatsApp** - `https://wa.me/<phone>` deep links
- No actual integration with APIs; relies on device capability

### Package Management
- NPM with package-lock.json v3
- Concurrent dev/build scripts for client and server
- TypeScript compilation checking without emit